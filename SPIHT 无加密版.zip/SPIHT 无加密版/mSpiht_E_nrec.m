function Egress = mSpiht_E_nrec(w_im, bit_budget, wlevel, dsb, R) %V0
global im_p bplane Smsk Egress ind d2 dhalf...
    LSP LIP LIS_ LIS lsp lip lis lis_ cnt d

% Written by Mustafa Sakalli, msakalli@cipr.rpi.edu
% Bits allocated: 12 o2 24 bits size, wlevel 4 bits, thr 3 or 7 bits.

sp_level = wlevel +2;
if ((sp_level<1)|(wlevel<1)), 
    display('The initial level of Sp can not be negative');
    clear;
    return; 
end
%remap dsb_ to dsb for expansion..
for rm=2:sp_level-1,
    dsb(rm, 3:4) = bitshift(dsb(rm-1, 3:4), 1)+dsb(rm, 3:4); 
end
R_ = 2^(R*8+wlevel+1);
rm_d = dsb(sp_level+1, 1:2)+ dsb(sp_level-1, 3:4)+bitget(dsb(sp_level+1, 1:2)+ dsb(sp_level-1, 3:4), 1);
im_ = repmat(R_, rm_d);
im_(1:dsb(2,1), 1:dsb(2,2)) = w_im(1:dsb(2,1), 1:dsb(2,2)); %1-1 map of LIS and LIP region.. 
for rm=1:sp_level-1, rm_ = 1+rm; rm__ = rm_+1;
    im_(dsb(rm, 3)+[1+dsb(rm_,1):dsb(rm__,1)], 1:dsb(rm_,2)) = w_im(1+dsb(rm_,1):dsb(rm__,1), 1:dsb(rm_,2));
    im_(1:dsb(rm_,1), dsb(rm, 4)+[1+dsb(rm_,2):dsb(rm__,2)]) = w_im(1:dsb(rm_,1), 1+dsb(rm_,2):dsb(rm__,2));
    im_(dsb(rm, 3)+[1+dsb(rm_,1):dsb(rm__,1)], dsb(rm, 4)+[1+dsb(rm_,2):dsb(rm__,2)]) = ...
        w_im(1+dsb(rm_,1):dsb(rm__,1), 1+dsb(rm_,2):dsb(rm__,2));
end


Smsk = repmat(0, rm_d);
Smsk(im_>(R_-1)) = -1; 
im_(im_>(R_-1)) = 0; 

w_im = im_;
bit_budget = bit_budget+8;
Egress = repmat(0, bit_budget, 1);

% One more bit to indicate if any coeff in LL band is negative
notnegative = 1 - any(any(w_im(1:dsb(1, 1), 1:dsb(1, 2))<0));
Smsk(w_im>0) = 1; bsh = [-1, 1];
w_im = round(w_im.*bsh((Smsk>0)+1)); 

% Thmax bitplane level should be bitplane level of image mean + wlevel
% that is 8 bit resolution + wlevel, therefore the maxlevel is taken 8+wlevel initially
max_bplev = R*8+wlevel+3; Thmax = max_bplev; im_ = w_im(1:dsb(3, 1), 1:dsb(3, 2));
if ~any(im_(:)) disp('Byte resolution entered should be wrong or increase the maximum number set to R_ at line 13!!'); 
    Egress = 0; return;
end
for t_ = Thmax:-1:floor((max_bplev-1)/3), 
    if any(bitget(im_(:), t_)), Thmax = t_; break; 
    end;
end;
if((Thmax == max_bplev) |~Thmax) Thmax = max(find(bitget(max(w_im(:)), 1:52)));   % Log2 process..
end
% Header.
Egress(1:5) = [(dsb(sp_level + 1, 1)~=dsb(sp_level + 1, 2))*dsb(sp_level + 1, 2),...
        dsb(sp_level + 1, 1), wlevel, Thmax-wlevel-3, notnegative]'; 
if (Thmax-wlevel-3)<1
    disp('Header for the binenc_ and bindec_, needs to be modified for this image characteristics,');, 
    disp('Image amplitude should be unusally low, send a message to msakalli@cipr.rpi.edu.');
    Egress = 0;
    return
end

% Note for binary images.. This program is not intended for binary images, but if it needs to be
% then change the Thmaz-Level-3, rediesng this..  
ind = 6;

% d is updated here for expanded image.. 
d = rm_d; %dsb(wlevel+3, 1:2); 
pd = d(1)*d(2);%numel(w_im);
d2 = 2:2:2*max(d);
dhalf = bitshift(d, -1)+1; 
im_p = 1:pd; im_p = reshape(im_p, d);   % Positions of all the coefficients in 1D.
sz_LL0 = prod(dsb(1,  1:2));

LIP = repmat(0, pd, 1); 
LSP = repmat(0, pd, 1);
LIS = repmat(0, bitshift(pd, -2), 3); 
LIS_ = repmat(0, bitshift(pd, -2), 3); 
% to replace LIS_ with LIS so that i can start from 1 to lis

% Initialize LIP
LIP(1:sz_LL0) = im_p(1:dsb(1,1), 1:dsb(1,2));   %  
LIP(sz_LL0+[1:dsb(1,1)*(dsb(2,2)-dsb(1,2))]) = ...
    im_p(1:dsb(1,1), dsb(1,2)+1:dsb(2,2)); 
LIP(sz_LL0+dsb(1,1)*(dsb(2,2)-dsb(1,2)) + [1:(dsb(2, 1)-dsb(1,1))*dsb(2,2)]) = ...
    im_p(dsb(1,1)+1:dsb(2, 1), 1:dsb(2,2)); 
% In general LIP covers initial roots of LIS in here..
lip = prod(dsb(2,1:2));

lis = dsb(1,1)*dsb(1,2)+2*dsb(1, 2)*dsb(1,1); % Initialize LIS
LIS(1:dsb(1,1)*dsb(1,2), 1:2) = [repmat(1:dsb(1,1), 1, dsb(1, 2))', ...
        reshape(repmat(dsb(1, 2)+1:2*dsb(1, 2), dsb(1,1), 1), dsb(1, 1)*dsb(1, 2), 1)];
LIS(dsb(1,1)*dsb(1,2)+[1:dsb(1,1)*dsb(1,2)*2], 1:2) = ...
        [repmat(dsb(1,1)+1:2*dsb(1,1), 1, 2*dsb(1,2))', ...
         reshape(repmat([1:2*dsb(1, 2)], dsb(1,1), 1), dsb(1, 1)*dsb(1, 2)*2, 1)];
% LIS(1:(dsb(1,1)-dsb(1,3))*(dsb(2,2)-dsb(1,2)), 1:2) = [repmat(1:(dsb(1,1)-dsb(1,3)), 1, dsb(2, 2)-dsb(1, 2))', ...
%         reshape(repmat(dsb(1, 2)+1:dsb(2, 2), (dsb(1,1)-dsb(1,3)), 1), (dsb(2, 2)-dsb(1, 2))*(dsb(1,1)-dsb(1,3)), 1)];
% LIS((dsb(1,1)-dsb(1,3))*(dsb(2,2)-dsb(1,2))+[1:(dsb(2, 2)-dsb(1,4))*(dsb(2,1)-dsb(1,1))], 1:2) = ...
%         [repmat(dsb(1,1)+1:dsb(2,1), 1, (dsb(2, 2)-dsb(1,4)))', ...
%          reshape(repmat([1:dsb(1, 2)-dsb(1,4), dsb(1, 2)+1:dsb(2,2)], dsb(2,1)-dsb(1,1), 1), (dsb(2, 2)-dsb(1,4))*(dsb(2,1)-dsb(1,1)), 1)];
% if dsb(1,3)
%     LIS((dsb(1,1)-1):(dsb(1,1)-1):(dsb(1,1)-1)*(dsb(2,2)-dsb(1,2)), 3) = 2;
% end
% if dsb(1,4)
%     LIS((dsb(1,1)-dsb(1,3))*(dsb(2,2)-dsb(1,2))+(dsb(1,2)-2)*(dsb(2,1)-dsb(1,1))+[1:(dsb(2,1)-dsb(1,1))], 3) = 2;
% end

cnt = 0;
Th = Thmax; 

% 1+
sz_LL0_ = sz_LL0; lsp =1; Indx(Th)=0;
while(ind < bit_budget)
    % Sorting 
    if (Th)
        bplane = bitget(w_im, Th); 
    else
        Egress = Egress(1:ind-1);
        disp('All the bits compressed, almost lossless compression!!.'); 
        return;
    end;
    lip_ = 1; k_ = 1;
    % The first quarter
    if (sz_LL0_ & notnegative)
        n_ = nnz(bplane(LIP(1:sz_LL0_))); ind_ = ind+sz_LL0_-1;
        Egress(ind:ind_) = bplane(LIP(1:sz_LL0_)); %bplane(LIP(1:sz_LL0_))=-1;
        LSP(lsp:lsp+ n_-1) = LIP(Egress(ind:ind_)>0); 
        LIP(lip_:lip_+ sz_LL0_ - n_-1) = LIP(Egress(ind:ind_)<1);
        ind = ind_ + 1; 
        lip_ = lip_ + sz_LL0_ - n_; 
        lsp = lsp + n_; k_ = sz_LL0_ +1;
        sz_LL0_ = sz_LL0_ - n_;
    end
    % Following quarters
    for k = k_:lip,
        if bplane(LIP(k)) 
            Egress(ind) = 1; %bplane(LIP(k))=-1;
            Egress(ind+1) = Smsk(LIP(k));%Smsk(LIP(k)) = 0; 
            ind = ind + 2; 
            LSP(lsp) = LIP(k);
            lsp = lsp + 1;
        else
            ind = ind +1;
            LIP(lip_) = LIP(k);  
            lip_ = lip_ +1;    
        end
        if (ind > bit_budget)
            Egress = Egress(1:bit_budget);
            return
        end
    end
    
    if ind > bit_budget
        Egress = Egress(1:bit_budget);
        return
    end
%     show(bplane);
    lip = lip_-1;        

    lis_ = 1; i = 1;  
    while (i <= lis) 
        if LIS(i,3)
%             if LIS(i,3)==1
                stem4([LIS(i,1:2); LIS(i,1:2)+1]);
%             elseif LIS(i,3)==2
%                 expendblock = dsb_(dsb_(dsb(:,3)>0, 1)==(LIS(i,1)+1), 3:4);
%                 if ~any(expendblock), 
%                     expendblock = dsb_(dsb_(dsb_(:,4)==1, 2)==(LIS(i,2)+1), 3:4);
%                     if ~any(expendblock), 
%                         disp('something seems wrong, point 152'); 
%                         pause; 
%                     end; 
%                 end;
%                 stem1_(LIS(i,1:2), expendblock); 
%             else 
%                 expendblock = dsb_(dsb_(dsb(:,3)>0, 1)==(LIS(i,1)+2), 3:4);
%                 if ~any(expendblock), expendblock = dsb_(dsb_(dsb_(:,4)==1, 2)==(LIS(i,2)+2), 3:4);
%                     if ~any(expendblock), 
%                         disp('something seems wrong, point 160'); 
%                         pause; 
%                     end; 
%                 end;
%                 stem4_([LIS(i,1:2); LIS(i,1:2)+1], expendblock);                
%             end
        else
            stem1(LIS(i,1:2));
        end
        if ind > bit_budget
            Egress = Egress(1:bit_budget);
            return
        end        
        i = i+1;
    end
    lis = lis_-1; LIS(1:lis, :) = LIS_(1:lis, :);
    
    if(Thmax - Th),   %#ok<BDLOG> % Start of Refining    
        if (ind+lsp_-1) < bit_budget
            Egress(ind:ind+lsp_-1) = bplane(LSP(1:lsp_)); %bplane(LSP(bplane(LSP(1:lsp_))==1))=-1;
            ind = ind + lsp_; 
        else 
            Egress(ind:bit_budget) = bplane(LSP(1:bit_budget-ind+1)); 
            return; 
        end;
    end;         Indx(Th)=ind;   % End of Refining    
%     show(bplane);
    Th = Th - 1; lsp_ = lsp-1; 
end
return


function  [Dflag] = f_Ch_Des(cp)
global bplane dhalf d2 d
Dflag=0; 
while (cp(2, :)<dhalf)
    cp = d2(cp); cp(1,:) = cp(1,:) -1;
    if any(any(bplane(cp(1,1):cp(2, 1),cp(1,2):cp(2, 2))>0)) 
        Dflag = Dflag + 1; 
        return; 
    end
end
if (cp(1, :)<dhalf)
    cp = d2(cp); cp(1,:) = cp(1,:) -1;
    cp(2, cp(2, :)>d)=d(cp(2, :)>d);
    if any(any(bplane(cp(1,1):cp(2, 1),cp(1,2):cp(2, 2))>0)) 
        Dflag = Dflag + 1; 
        return; 
    end
end    
return


% function  [Dflag] = f_Ch_Des_(cp, E)
% global bplane dhalf d2 dsb
% Dflag=0; 
% while (cp(2, :)<dhalf)
%     cp = d2(cp); cp(1,:) = cp(1,:) -1; cp(2,:) = cp(2,:) +E;
%     if any(any(bplane(cp(1,1):cp(2, 1),cp(1,2):cp(2, 2)))) 
%         Dflag = Dflag + 1; 
%         return; 
%     end
% end
% return
% 

function stem1(clover)
global im_p bplane Smsk Egress ind d2 dhalf
global LSP LIP LIS LIS_ lsp lip lis lis_ cnt
if (f_Ch_Des([clover; clover]))
    Egress(ind) = 1;
    ind = ind+  1;
    cp = d2([clover; clover]); cp(1, :) = cp(1, :) -1;   
    cp_ = (im_p(cp(1, 1):cp(2, 1), cp(1, 2):cp(2, 2)))';
    for kk=1:4
        if (Smsk(cp_(kk))>-1)
            if bplane(cp_(kk)) %bplane(cp_(kk))=-1;
                Egress(ind:ind+1) = [1, Smsk(cp_(kk))];
                ind = ind + 2; %Smsk(cp_(kk)) =0;
                LSP(lsp) = cp_(kk); 
                lsp = lsp + 1; 
            else
                ind = ind + 1;
                lip = lip + 1;
                LIP(lip) = cp_(kk);
            end
            %         else
            %             cnt = cnt+1;
        end
    end
    if cp(2, :)<dhalf
        lis = lis + 1;  
        LIS(lis, 1:3) = [cp(1, :) 1]; 
    elseif cp(1, :)<dhalf %This is the remaning half type B block but append the remaining elements as A..
        lis = lis + 1;  
        LIS(lis, 1:3) = [cp(1, :) 0]; 
        lis = lis + 1;  
        LIS(lis, 1:3) = [cp(2-(dhalf(1)==cp(2,1)), 1) cp(2-(dhalf(2)==cp(2,2)), 2) 0]; 
%     elseif cp(:, 1)<dhalf(1) % The same reason as above
%         lis = lis + 1;  
%         LIS(lis, 1:3) = [cp(1, :) 0]; 
    end
else
    ind = ind + 1;
    LIS_(lis_, 1:3) = [clover 0]; 
    lis_ = lis_ + 1; 
end
return;

% function stem1_(clover, E)
% global im_p bplane Smsk Egress ind d2 dhalf
% global LSP LIP LIS LIS_ lsp lip lis lis_
% if f_Ch_Des_([clover; clover], E)
%     Egress(ind) = 1;
%     ind = ind+  1;
%     cp = d2([clover; clover]); cp(1, :) = cp(1, :) -1; cp(2,:) = cp(2,:) +E;  
%     cp_ = (im_p(cp(1, 1):cp(2, 1), cp(1, 2):cp(2, 2)))';
%     for kk=1:numel(cp_)
%         if bplane(cp_(kk)) %bplane(cp_(kk))=-1;
%             Egress(ind:ind+1) = [1, Smsk(cp_(kk))];
%             ind = ind + 2; %Smsk(cp_(kk)) =0;
%             LSP(lsp) = cp_(kk); 
%             lsp = lsp + 1; 
%         else
%             ind = ind + 1;
%             lip = lip + 1;
%             LIP(lip) = cp_(kk);
%         end
%     end
%     if cp(2, :)<dhalf
%         lis = lis + 1;  
%         LIS(lis, 1:3) = [cp(1, :) 3]; 
%     end
% else
%     ind = ind + 1;
%     LIS_(lis_, 1:3) = [clover 2]; 
%     lis_ = lis_ + 1; 
% end
% return;


function stem4(cp)
global Egress LIS LIS_ ind lis lis_
if f_Ch_Des(cp)
    L = lis + 4;
    LIS(L-3:L, 1:3) = ...
        [cp(1, :)  0;  cp(2, 1) cp(1, 2) 0; ...
        cp(1, 1) cp(2, 2) 0; cp(2, :) 0];
    Egress(ind) = 1;
    lis = L;
else
    LIS_(lis_, 1:3) = [cp(1, :) 1];
    lis_ = lis_ + 1;
end
ind = ind + 1;
return

% function stem4_(cp, E)
% global Egress LIS LIS_ ind lis lis_
% if f_Ch_Des(cp + [0 0; E])
% %     L = lis + 4; 
% %     LIS(L-3:L, 1:3) = ...
% %         [cp(1, :)  0;  cp(2, 1) cp(1, 2) 0; ...
% %             cp(1, 1) cp(2, 2) 0; cp(2, :) 0];
%     L = lis; 
%     if E(2) % h
%         L=L+4;
%         LIS(L-3:L, 1:3) = ...
%         [cp(1, :)  2;  cp(2, 1) cp(1, 2) 0; ...
%             cp(1, 1) cp(2, 2) 2; cp(2, :) 0];
% %             [cp(:, 1), cp(2, 2)+[1; 1], [2; 2]];
%     end
%     if E(1) % v
%         L=L+4;
%         LIS(L-3:L, 1:3) = ...
%         [cp(1, :)  0;  cp(2, 1) cp(1, 2) 2; ...
%             cp(1, 1) cp(2, 2) 0; cp(2, :) 2];
% %             [cp(2, 1)+[1; 1], cp(:, 2), [2; 2]];
%     end 
%     if prod(E) % d
%         L=L+1;
%         LIS(L, 1:3) = ...
%             [cp(2, :)+E 2];
%     end
%     Egress(ind) = 1;
%     lis = L;
% else
%     LIS_(lis_, 1:3) = [cp(1, :) 3];
%     lis_ = lis_ + 1;
% end
% ind = ind + 1;
% return