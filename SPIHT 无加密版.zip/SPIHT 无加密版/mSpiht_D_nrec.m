function [im] = mSpiht_D_nrec(Inp)
global im im_p Smsk ind d d2 dhalf L_In Thr Ingress... 
    LSP LIP LIS LIS_ lsp lip lis lis_ 

% Written by Mustafa Sakalli, msakalli@cipr.rpi.edu
Ingress = Inp(:);  clear Inp; 
d(1:2) = [Ingress(2), Ingress(1)+(Ingress(1)==0)*Ingress(2)];

sp_level = Ingress(3)+2;
Thmax = Ingress(3) + Ingress(4) + 3;
notnegative = Ingress(5); 
ind = 6;

%wlevel = sp_level -2;
dsb(sp_level+1, 1:2) = d;

for jscl=sp_level:-1:1,
    dsb(jscl, 1:2) = bitshift(dsb(jscl+1, 1:2), -1)+bitget(dsb(jscl+1, 1:2), 1);
    dsb(jscl, 3:4) = bitget(dsb(jscl+1, 1:2), 1);
end

%dd = max(bitget(min(r_im, c_im)-1, [1:12]).*[1:12]); %Dyadic Depth 
% dsb(1:sp_level, 1) = bitshift(d(1), [-sp_level:-1]')+bitget(d(1),1);
% dsb(1:sp_level, 2) = bitshift(d(2), [-sp_level:-1]')+bitget(d(2),1);
% dsb(1:sp_level, 3:4) = bitget(dsb(2:sp_level+1, 1:2), 1); 

%when dsb_ was remapped to dsb
for rm=2:sp_level-1,
    dsb(rm, 3:4) = bitshift(dsb(rm-1, 3:4), 1)+dsb(rm, 3:4); 
end

% d is updated here for expanded image.. 
d = dsb(sp_level+1, 1:2)+ dsb(rm, 3:4)+bitget(dsb(sp_level+1, 1:2)+ dsb(rm, 3:4), 1);
Smsk = repmat(0, d);

Smsk(1:dsb(2,1), 1:dsb(2,2)) = 1; 
for rm=1:sp_level-1, rm_ = rm+1;
    Smsk(dsb(rm, 3)+[1+dsb(rm_,1):dsb(2+rm,1)], 1:dsb(rm_,2)) = 1;
    Smsk(1:dsb(1+rm,1), dsb(rm, 4)+[1+dsb(rm_,2):dsb(2+rm,2)]) = 1;
    Smsk(dsb(rm, 3)+[1+dsb(rm_,1):dsb(2+rm,1)], dsb(rm, 4)+[1+dsb(rm_,2):dsb(2+rm,2)]) = 1;
end

pd = prod(d);
d2 = 2:2:2*max(d);
dhalf = bitshift(d, -1)+1;
im = repmat(0, d);  
im_p = 1:pd; im_p = reshape(im_p, d);

LIP = repmat(0, pd, 1);
LSP = repmat(0, pd, 1); 
LIS = repmat(0, bitshift(pd, -2), 3);
LIS_ = repmat(0, bitshift(pd, -2), 3);


sz_LL0 = prod(dsb(1, 1:2));

if ~(sz_LL0), 
    disp(sprintf('Inapplicable decomp level:''%d''!! returning 0 image', sp_level)); 
    im = -1; return;
end


% Initialize LIP
LIP(1:sz_LL0) = im_p(1:dsb(1,1), 1:dsb(1,2));   %  
LIP(sz_LL0+[1:dsb(1,1)*(dsb(2,2)-dsb(1,2))]) = ...
    im_p(1:dsb(1,1), dsb(1,2)+1:dsb(2,2)); 
LIP(sz_LL0+dsb(1,1)*(dsb(2,2)-dsb(1,2)) + [1:(dsb(2, 1)-dsb(1,1))*dsb(2,2)]) = ...
    im_p(dsb(1,1)+1:dsb(2, 1), 1:dsb(2,2)); 
% In general LIP covers initial roots of LIS in here..
lip = prod(dsb(2,1:2));

lis = dsb(1,1)*dsb(1,2)+2*dsb(1, 2)*dsb(1,1); % Initialize LIS
LIS(1:dsb(1,1)*dsb(1,2), 1:2) = [repmat(1:dsb(1,1), 1, dsb(1, 2))', ...
        reshape(repmat(dsb(1, 2)+1:2*dsb(1, 2), dsb(1,1), 1), dsb(1, 1)*dsb(1, 2), 1)];
LIS(dsb(1,1)*dsb(1,2)+[1:dsb(1,1)*dsb(1,2)*2], 1:2) = ...
        [repmat(dsb(1,1)+1:2*dsb(1,1), 1, 2*dsb(1,2))', ...
         reshape(repmat([1:2*dsb(1, 2)], dsb(1,1), 1), dsb(1, 1)*dsb(1, 2)*2, 1)];

 % cnt_=0;
Th = Thmax; 

lsp_ = 0; 

qu = repmat(0, 5, 1);
L_In = length(Ingress);
Ingress(L_In+10) = 0; 

sz_LL0_ = sz_LL0; lsp =1;
while (ind < L_In)
    if (Th-1)>0
        Thr = sum(bitset(0, [Th, Th-1])); 
    elseif (Th)
        Thr = Th;
    else
        break;
    end;    
    %Sorting Pass
    lip_ = 1; k_ = 1;
    % The first quarter
    if (sz_LL0_ & notnegative)
        ind_ = sz_LL0_+ ind-1; 
        if ind_> L_In
            ind_ = L_In; sz_LL0_ = L_In-ind+1;
%             return
        end
        n_ = sum(Ingress(ind:ind_));
        LSP(lsp:lsp + n_-1) = LIP(Ingress(ind:ind_)>0);
        LIP(lip_:lip_ + sz_LL0_ - n_-1) = LIP(Ingress(ind:ind_)<1);
        im(LSP(lsp:lsp + n_-1)) = Thr;  
        ind = ind_ + 1; 
        lip_ = lip_ + sz_LL0_ - n_; 
        lsp = lsp + n_; k_ = sz_LL0_ +1;
        sz_LL0_ = sz_LL0_ - n_;
    end
    
    for i = k_:lip,
        if ind> L_In
im = remap_btoo(im, dsb, sp_level-1);
            return
        end
        if Ingress(ind)
            ind = ind + 1;
            if Ingress(ind),
                im(LIP(i)) = Thr;  
            else
                im(LIP(i)) = - Thr; Smsk(LIP(i)) = 3;
            end
            LSP(lsp) = LIP(i);  lsp = lsp + 1;
        else
            LIP(lip_) = LIP(i);  lip_ = lip_ + 1;          
        end
        ind = ind + 1;
    end
    lip = lip_ -1;
    lis_ = 1; i = 1;
    while ( i <= lis)
        if ind > L_In
im = remap_btoo(im, dsb, sp_level-1);
            return
        end
        if LIS(i,3)
            stem4([LIS(i,1:2); LIS(i,1:2)+1]);
        else
            stem1(LIS(i,1:2));
        end
        if ind > L_In
im = remap_btoo(im, dsb, sp_level-1);
            return
        end
        i = i+1;
    end
    lis = lis_-1;    LIS(1:lis, :) = LIS_(1:lis, :);
    
    % Refinement Pass 
    if (Thmax-Th), 
        if (Th-1)>0
            qu(2) = Thr/3; qu(1) = -qu(2); qu(3) = qu(2); qu(4) = qu(1);
        else
            qu(1) = -1; qu(2) = 0; qu(3) = -qu(1); qu(4) = qu(2);
        end
        if (ind+lsp_-1)<L_In+1
            im(LSP(1:lsp_)) = im(LSP(1:lsp_)) + ...
                qu(Ingress(ind:ind+lsp_-1)+Smsk(LSP(1:lsp_)));
            ind = ind + lsp_;
        else
            lspe = L_In - ind + 1;
            im(LSP(1:lspe)) = im(LSP(1:lspe))+ ...
                qu(Ingress(ind:ind+lspe-1)+Smsk(LSP(1:lspe)));
im = remap_btoo(im, dsb, sp_level-1);
            return
        end        
    end
    lsp_ = lsp -1;
    Th = Th-1;
end
im = remap_btoo(im, dsb, sp_level-1);
return

%remap back to the originalsize
function im = remap_btoo(im, dsb, l_)
for rm=1:l_, rm_ = 1+rm;  rm__ = 2+rm;
    im(1+dsb(rm_,1):dsb(rm__,1), 1:dsb(rm_,2)) = im(dsb(rm, 3)+[1+dsb(rm_,1):dsb(rm__,1)], 1:dsb(rm_,2));
    im(1:dsb(rm_,1), 1+dsb(rm_,2):dsb(rm__,2)) = im(1:dsb(rm_,1), dsb(rm, 4)+[1+dsb(rm_,2):dsb(rm__,2)]);
    im(1+dsb(rm_,1):dsb(rm__,1), 1+dsb(rm_,2):dsb(rm__,2)) = ...
        im(dsb(rm, 3)+[1+dsb(rm_,1):dsb(rm__,1)], dsb(rm, 4)+[1+dsb(rm_,2):dsb(rm__,2)]);
end
im = im(1:dsb(rm__,1), 1:dsb(rm__,2));
return


function stem1(clover)
global im im_p Smsk Ingress ind L_In Thr d2 dhalf...
    LSP LIP LIS LIS_ lsp lip lis lis_ 
if ind > L_In
    return
end
if Ingress(ind)
    ind = ind + 1;                
    cp = d2([clover; clover]); cp(1, :) = cp(1, :) -1;   
    cp_ = (im_p(cp(1, 1):cp(2, 1), cp(1, 2):cp(2, 2)))';
    for kk=1:4    
        if ind > L_In
            return
        end
        if Smsk(cp_(kk))
            if Ingress(ind)
                ind = ind + 1;
                LSP(lsp) = cp_(kk); 
                lsp = lsp + 1;
                if ind > L_In
                    return
                end
                if Ingress(ind)
                    im(cp_(kk)) = Thr; 
                else
                    im(cp_(kk)) = -Thr; Smsk(cp_(kk)) = 3;
                end
            else
                lip = lip + 1;
                LIP(lip) = cp_(kk);
            end                         
            ind = ind + 1;
        end
    end
    if cp(2, :) < dhalf
        lis = lis + 1;
        LIS(lis, :) = [cp(1, :) 1]; 
    elseif cp(1, :)<dhalf %This is remaning half type B block but append the remaining elements as A..
        lis = lis + 1;  
        LIS(lis, 1:3) = [cp(1, :) 0]; 
        lis = lis + 1;  
        LIS(lis, 1:3) = [cp(2-(dhalf(1)==cp(2,1)), 1) cp(2-(dhalf(2)==cp(2,2)), 2) 0]; 
%     elseif cp(:, 1)<dhalf(1) % The same reason as above
%         lis = lis + 1;  
%         LIS(lis, 1:3) = [cp(1, :) 0]; 
    end
else
    ind = ind + 1;
    LIS_(lis_, :) = [clover 0]; 
    lis_ = lis_ + 1; 
end
return;

function stem4(cp)
global Ingress ind LIS lis LIS_ lis_ L_In
if ind > L_In
    return
end
if Ingress(ind)
    L = lis;
    L = L + 4;
    LIS(L-3:L, :) = [...
            repmat([cp(1, :)  0;  cp(2, 1) cp(1, 2) 0; ...
                cp(1, 1) cp(2, 2) 0; cp(2, :) 0], 1, 1)];
    lis = L;
else
    LIS_(lis_, :) = [cp(1, :) 1]; 
    lis_ = lis_ + 1;
end
ind = ind +1; 
return