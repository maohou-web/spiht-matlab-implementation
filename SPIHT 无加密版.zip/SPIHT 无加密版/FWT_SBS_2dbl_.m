function [X, dl] = FWT2_SBS_2dbl(X, dl, qmf, dqmf, Ln, flL, flH)
% Note we assume that signal length always is larger than the half+1 filter length.. 
%Note	% symmetric extension of odd filters, odd_(1) is the oddness of signal.. 

% FWT_SBS_2dbl -- 1-dimensional wavelet transform
%              (symmetric extension, bi-orthogonal)
%  Inputs
%    X     2-d image (n by n array, n arbitrary)
%    L     coarsest level
%    qmf   low-pass quadrature mirror filter
%    dqmf  high-pass dual quadrature mirror filter
%    Ln, flL, flH =signal and filter lengths respectively 
%  Output
%    X    Wavelet transformed image
%  
%  Description
%    A two-dimensional Wavelet Transform is computed for the
%    matrix X. To reconstruct, use IWT2_SBS_2d.

% Modified from the WaveLab Version 802 
%      by Mustafa Sakalli, 
%      CIPR, RPI, msakalli@cipr.rpi.edu

Lnc = Ln(1);
Lnr = 1; %1d
if numel(X)>Ln(1)
    if numel(Ln)>1, %rect
        Lnr = Lnc; Lnc = Ln(2); 
    else
        Lnr = Lnc;  %sholud be sq!!
        Lnc = numel(X)/Lnr; 
    end
end

%%% FD_odd = bitget(flL-flH, 1); %Filter lenght difference if even or odd.. 
hflL_ = bitshift(flL,-1); hflH_ = bitshift(flH,-1);
mdqmf = ( (-1).^((-hflH_):hflH_) ).*dqmf; 
dl(2) = dl(1);
% Note we assume that signal length always is larger than the half+1 filter length.. 
if Lnr>1, 
    [X, dl(1)] = DownDy_SBS_1d_blck(X, dl(1), qmf, mdqmf, Lnr, flL, flH, hflL_, hflH_);
end

if Lnc>1,
    [X, dl(2)] = DownDy_SBS_1d_blck(X', dl(2), qmf, mdqmf, Lnc, flL, flH, hflL_, hflH_);
    X = X';
end
return


% Note we assume that signal length always is larger than the half+1 filter length.. 
function [X, dl] = DownDy_SBS_1d_blck(X, dl, qmf, mdqmf, Ln, flL, flH, hflL_, hflH_)
%Note: symmetric extension of odd filters, odd_x 2*bitget(Lnc, 1) is the oddness of signal.. 
 
dd = max(bitget(Ln-1, [1:32]).*[1:32]); 
% This definition of dyadic depth assumes possibility of extentions..
for S=dd-1:-1:dl, %split
%     if (Ln<flL-1), 
% %        disp(sprintf('Att: %d level decomposition is realized, Desired level L was %d', dd-S-1, dd-dl));
%         dl = dd+1;
%         return;
%     end
    c = bitshift(Ln, -1)+bitget(Ln, 1); %split somewhere around center
    
    %symmetric extending and filtering
    [alpha] = filter(qmf, 1, [X(hflL_+2:-1:2, :); X(1:Ln, :); X(Ln-1:-1:Ln-hflL_, :)]);
    [beta]  = filter(mdqmf, 1, [X(hflH_+1:-1:2, :); X(1:Ln, :); X(Ln-1:-1:Ln-hflH_, :)]);
    
    %downsampling
    X(1:c, :) = alpha(flL+[1:2:Ln], :);
    X(c+1:Ln, :) = beta(flH+[1:2:Ln-2*bitget(Ln, 1)], :);    
    Ln = c; %Update the length for next subband
end
return
