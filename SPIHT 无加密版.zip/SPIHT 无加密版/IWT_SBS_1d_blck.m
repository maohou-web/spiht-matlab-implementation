%This is like line buffer, the number of lines treated (in 1d) at once is Lnc..
function X = IWT_SBS_1d_blck(X, mqmf, dqmf, La, Ln, fl, ...
                                flL_, flH_, ex_H, ex_L, Lnc)
% UpDyad_SBS -- Symmetric Upsampling and Filtering operator
% fl(1, 1), fl(1, 2), fl(2, 1), fl(2, 2) = flL, flH, hflL_, hflH_;
    ALpHa = X(1:La, :); 
    BeTa = X(La+1:Ln, :);
    Lb = Ln-La;

    odd_X = bitget(Ln, 1);

    %H side, extending, upsampling and filtering 
    Ups = repmat(0, ex_H+2*La, Lnc);
    Ups(1:2:ex_H+2*La, :) =[ALpHa(fl(2, 2):-1:2, :); ...
            ALpHa; ALpHa(La-odd_X:-1:La-fl(2, 2)+~odd_X, :)];
    Coarse = filter(dqmf, 1, Ups);%(La:-1:La-bitshift(flH,-1)+2)
    
    %dl side, extending, upsampling and filtering 
    Ups = repmat(0, ex_L+2*Lb, Lnc);
    Ups(1:2:ex_L+2*Lb, :) = [BeTa(fl(2, 1)-1:-1:1, :);... 
            BeTa; BeTa(Lb-~odd_X:-1:Lb-fl(2, 1)+1+odd_X, :)];
    Fine = filter(mqmf, 1, Ups);
    
    %substituting.. 
    X(1:Ln, :) = Coarse(fl(1, 2)+[1:Ln], :) + Fine(fl(1, 1)+[1:Ln], :);
return
% Modified by Mustafa Sakalli, 2005, msakalli@CIPR.RPI.EDU  
% Originally Part of WaveLab Version 802
% This is Copyrighted Material
% For Copying permissions see COPYING.m
