function X = FWT2_SBS_2dbl(X, dl, qmf, mdqmf, dsb, fl)
% Note we assume that signal length always is larger than the half+1 filter length.. 
%Note	% symmetric extension of odd filters, odd_(1) is the oddness of signal.. 

% FWT_SBS_2dbl -- 1-dimensional wavelet transform
%              (symmetric extension, bi-orthogonal)
%  Inputs
%    X     2-d image (n by n array, n arbitrary)
%    L     coarsest level
%    qmf   low-pass quadrature mirror filter
%    dqmf  high-pass dual quadrature mirror filter
%    fl    the full&half lengths of filters 
%    dsb   each subband dimension
%  Output
%    X    Wavelet transformed image
%  
%  Description
%    A two-dimensional Wavelet Transform is computed for the
%    matrix X. To reconstruct, use IWT2_SBS_2d.

% Modified from the WaveLab Version 802 
%      by Mustafa Sakalli, 
%      CIPR, RPI, msakalli@cipr.rpi.edu

% Lnc = dsb(dl(2) ,2);
% Lnr = dsb(dl(2) ,1);

%%% FD_odd = bitget(flL-flH, 1); %Filter lenght difference if even or odd.. 

for wl=dl:-1:1, wl_ = wl+1;%split 
% Note we assume that signal length always is larger than the half+1 filter length.. 
    X(1:dsb(wl_, 1), 1:dsb(wl_, 2)) = DownDy_SBS_1d_blck(X(1:dsb(wl_, 1), 1:dsb(wl_, 2)),...
        qmf, mdqmf, dsb(wl ,1), dsb(wl_ ,1), fl); %rowwise
    X(1:dsb(wl_, 1), 1:dsb(wl_, 2)) = ...
    DownDy_SBS_1d_blck(X(1:dsb(wl_, 1), 1:dsb(wl_, 2))',...
        qmf, mdqmf, dsb(wl ,2), dsb(wl_ ,2), fl)'; %columnwise
end
return
