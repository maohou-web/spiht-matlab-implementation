function [Remaped, dsp_sp]= mSpiht_E_nrec(w_im, wlevel, dsb_) %V0

% Written by Mustafa Sakalli, msakalli@cipr.rpi.edu
dsb_sp = dsb_;
sp_level = wlevel +2;

% remap im_p for the semi columns and rows..
sb_v = 0; sb_h = 0;
for rm=1:sp_level-1,
    sb_v = bitshift(sb_v, 1);
    sb_h = bitshift(sb_h, 1);
    if dsb_(rm, 3)
        sb_v = sb_v+1;
    end
    if dsb_(rm, 4)
        sb_h = sb_h+1;
    end
    dsb_sp(rm, 3:4) = [sb_v, sb_h];
end
im_ = repmat(0, dsb_sp(sp_level+1, 1:2)+ dsb_sp(rm, 3:4));
im_(1:dsb_sp(2,1), 1:dsb_sp(2,2)) = w_im(1:dsb_sp(2,1), 1:dsb_sp(2,2)); %1-1 map of LIS and LIP region.. 
for rm=1:sp_level-1,
    im_(dsb_sp(rm, 3)+[1+dsb_sp(1+rm,1):dsb_sp(2+rm,1)], 1:dsb_sp(1+rm,2)) = w_im(1+dsb(1+rm,1):dsb(2+rm,1), 1:dsb(1+rm,2));
    im_(1:dsb_sp(1+rm,1), dsb_sp(rm, 4)+[1+dsb_sp(1+rm,2):dsb_sp(2+rm,2)]) = w_im(1:dsb(1+rm,1), 1+dsb(1+rm,2):dsb(2+rm,2));
    im_(dsb_sp(rm, 3)+[1+dsb_sp(1+rm,1):dsb_sp(2+rm,1)], dsb_sp(rm, 4)+[1+dsb_sp(1+rm,2):dsb_sp(2+rm,2)]) = ...
        w_im(1+dsb(1+rm,1):dsb(2+rm,1), 1+dsb(1+rm,2):dsb(2+rm,2));
end
return