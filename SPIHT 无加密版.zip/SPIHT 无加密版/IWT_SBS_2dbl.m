function X = IWT_SBS_2dbl(X, dl, mqmf, dqmf, dsb, fl)
% IWT_SBS_2d -- Inverse 1d Wavelet Transform
%    (symmetric extention, bi-orthogonal, for images dimension > filter length)
%  Usage
%    X = IWT2_SBS(wc,dl,qmf,dqmf, Ln, flL, flH)
%  Inputs
%      X    2-d wavelet transform [n by n array, n arbitrary]
%      dl   WL Composition level
%      qmf   low-pass quadrature mirror filter
%      dqmf  high-pas dual quadrature mirror filter
%      fl    the full&half lengths of filters 
%      dsb   each subband dimension
%  Outputs
%      X  The signal reconstructed from X 
%  Description
%  If X is the result of a forward 2d wavelet transform, with
%      X = FWT2_SBS_2d(X,dl,qmf,dqmf, Ln, flL, flH) 
% signal can be 1 or 2 d and the length can be entered for one or two dimensional.. 


% Modified from the WaveLab Version 802 
%      by Mustafa Sakalli, 
%      CIPR, RPI, msakalli@cipr.rpi.edu


flH_ = bitset(fl(1, 2), 1, 0); %if odd (flH-1)
flL_ = bitset(fl(1, 1), 1, 0); %if odd (flL-1)

ex_H = bitshift(flH_-1, 1);
ex_L = bitshift(flL_-2, 1);


for wl=1:dl, wl_ = wl+1; % merging wl of two bands
% Note we assume that signal length always is larger than the half+1 filter length.. 
X(1:dsb(wl_, 1), 1:dsb(wl_, 2)) = IWT_SBS_1d_blck(IWT_SBS_1d_blck(X(1:dsb(wl_, 1), 1:dsb(wl_, 2))',... 
    mqmf, dqmf, dsb(wl ,2), dsb(wl_ ,2), fl, flL_, flH_, ex_H, ex_L, dsb(wl_ ,1))', ...
    mqmf, dqmf, dsb(wl ,1), dsb(wl_ ,1), fl, flL_, flH_, ex_H, ex_L, dsb(wl_ ,2));
%dl, dl(2), dpm, flL, flH, flL_, flH_, hflL_, hflH_, ex_H, ex_L, Lnr)';
end

return
