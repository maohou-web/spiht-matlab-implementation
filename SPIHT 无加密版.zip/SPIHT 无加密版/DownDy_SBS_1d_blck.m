% Note we assume that signal length always is larger than the filter length.. 
function [X, dl] = DownDy_SBS_1d_blck(X, qmf, mdqmf, c, Ln, fl)
%Note: symmetric extension of odd filters, odd_x 2*bitget(Lnc, 1) is the oddness of signal.. 
% fl(1, 1), fl(1, 2), fl(2, 1), fl(2, 2) = flL, flH, hflL_, hflH_;

% dd = max(bitget(Ln-1, [1:32]).*[1:32]); 
% This definition of dyadic depth assumes possibility of extensions..

%    c = bitshift(Ln, -1)+bitget(Ln, 1); %split somewhere around center
    
    %symmetric extending and filtering
    [alpha] = filter(qmf, 1, [X(fl(2, 1)+2:-1:2, :); X(1:Ln, :); X(Ln-1:-1:Ln-fl(2, 1), :)]);
    [beta]  = filter(mdqmf, 1, [X(fl(2, 2)+1:-1:2, :); X(1:Ln, :); X(Ln-1:-1:Ln-fl(2, 2), :)]);

    %downsampling
    X(1:c, :) = alpha(fl(1,1)+[1:2:Ln], :);
    X(c+1:Ln, :) = beta(fl(1,2)+[1:2:Ln-bitshift(bitget(Ln, 1), 1)], :);    
%     Ln = c; %Update the length for next subband
    %end
return
% Modified by Mustafa Sakalli, 2005, msakalli@CIPR.RPI.EDU  
% Originally Part of WaveLab Version 802
% This is Copyrighted Material
% For Copying permissions see COPYING.m

