function [Bin_DecSeq] = BinDec_(fname)
% 
% Written by Mustafa Sakalli
% msakalli@cipr.rpi.edu
% read BenEnc_ for header information.. R allocates 4 bits more for higher byte resolution
fid = fopen(fname,'r');
if (fid== -1) 
    txt = sprintf('Cannot open image file %s in the current directory.', fname); 
    disp(txt);
    return;
end

txt = sprintf('Reading binary file, %s', fname);
[X L]= fread(fid, 'uint32');
fseek(fid, -(ftell(fid)-L*4), 1);
[X_ L_]= fread(fid, 'uint8');
fclose(fid);

SQ = bitand(X(1), 1); ifsq = SQ*12; SQ_ = ~SQ; R_ =0;

Bin_DecSeq = repmat(0, bitshift(L, 5)+ifsq+4+bitshift(L_, 3), 1);

Bin_DecSeq(1) = bitand(bitshift(X(1), -1), 4095); %sz
Bin_DecSeq(2) = bitand(bitshift(X(1), -ifsq-1), 4095); %sz
Bin_DecSeq(3) = bitand(bitshift(X(1), -13-ifsq), 15); %wlev
Bin_DecSeq(4) = bitand(bitshift(X(1), -17-ifsq), 7); %thr
if ~(Bin_DecSeq(4)), 
    if (ifsq),
        Bin_DecSeq(4) = bitand(X(2), 15)+8;
        Bin_DecSeq(5:32) = bitget(X(2), [5:32]);
        R_= -28; j = 3;        
    else
        R_ =4; j =2;        
        Bin_DecSeq(4) = bitand(bitshift(X(1), -20), 15)+8;
        Bin_DecSeq(5:12) = bitget(X(1), [25:32]); %16-ifsq-R_, 21+R_+ifsq
    end;
else 
   Bin_DecSeq(5:16-ifsq) = bitget(X(1), [21+ifsq:32]);
   j = 2;
end; 
if (Bin_DecSeq(4)==15), Bin_DecSeq(4) =0; end; %Thr

a1_32 = 1:32; J = 16+[1:32]-(ifsq+R_);
for i = j:L, 
    Bin_DecSeq(J) = bitget(X(i), a1_32);
    J = J+32;
end

l_ = J(1);
J = J(1:8);
for i = 1:L_, 
    Bin_DecSeq(J) = bitget(X_(i), 1:8);
    l = max(J(Bin_DecSeq(J)>0));
    if l, l_ = l; end; 
    J = J+8;
end
Bin_DecSeq(l_+1:end) = [];
return