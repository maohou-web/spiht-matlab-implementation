function BinEnc(fname, Bitstobeencoded)

% Written by Mustafa Sakalli msakalli@cipr.rpi.edu
SQ = Bitstobeencoded(1)&1; ifsq = SQ*12;
% for 2 or more bytes resolution..
R = 0; R_ = 0; % Note: Since Bitstobeencoded(4) = Thmax-sp_level-1  < 8 bits resolution 
% since the Expect(Thr)<=wlevel+mean-1, therefore 3 bits
if Bitstobeencoded(4)>7, R= Bitstobeencoded(4)-8; R_=4; Bitstobeencoded(4)=0;
elseif ~Bitstobeencoded(4), R=31; R_=4;   
end
% Note to remember: 0-7 was for 8 bit resolution.. zero can not happen, Thr=1 is binary case. 
% therefore it is mapped to the R = 31, and Bitstobeencoded(4) = 0; 
% maximum resolution that can be mapped is 31.. inother words R=0, Bitstobeencoded(4) = 0 is Thr =8.   
% 4 bits allocated for Resolution >1..  
% bL = length(Bitstobeencoded)-3+16;
room = 12-ifsq-R_; %remaining bits;
bL = length(Bitstobeencoded)-4-room;
L = bitshift(bL, -5)+1; 
Enc_Sec = repmat(0, L, 1);
a1_32=1:32;
Enc_Sec(1) = SQ + ... % 1 b
                bitshift(Bitstobeencoded(1) , 1)*SQ  + ... % SQ and sz1, 
                bitshift(Bitstobeencoded(2), 1+ifsq) + ...% sz2, [14:25] or [2:13] %maxsize of image 2^12
                bitshift(Bitstobeencoded(3), 13+ifsq) + ...% wLev [26:29] or [14:17] %upto 12 lev, 4 bits
                ~R*bitshift(Bitstobeencoded(4), 17+ifsq) + ...% ~R inserts 000. Thr [30:32] or [18:20] % 3bits or 4 bits more if R>0
                ~SQ*(bitshift(R, (20+ifsq)) + ...% room = 12-ifsq-R_  
                sum(bitset(Enc_Sec(1), 20+R_+a1_32(1&Bitstobeencoded(4+[1:room]))))); 
                % this is to fill the remaining bits. Inhibited if(SQ = 1) since no room remaining. 
% The last line 
% 3*(R>0)+[18:20] if SQ=0, 3 b allctd [18:20], res =1 byte. 1+12+4+3, 12 bits space remainingg
% 3*(R>0)+[18:20] if SQ=0, +4 b allcd [21:24], res >1 byte. 1+12+4+3+4, 8 bits space remaining
% 3*(R>0)+[18:20] if SQ=1, 3 b 12+[18:20], res =1 byte. 1+24+4+3, no space remaining but R is fixed in.
% 3*(R>0)+[18:20] if SQ=1, +4 b 12+[21:24], res >1 byte. 1+24+4+3+4. no space remaining, R is not in
% Bits
% [1  2 . . . . . 8 . . . . 13 . . 16 . 18 . 20 . . . 24 . . . . . 30 . 32  33......
% case: if SQ =0; Square, R=0 Thr allocated 3 bits
% [SQ,sz1 . . . . 8 . . . .  . wlev . . Thr  20]subsequentbits
% case: if SQ =1; Rectgl, R=0
% [SQ,sz1 . . . . 8 . . . . sz2  . 16 . .  . 20 . . . 24 . wlev. . Thr . 32] subsequentbits
% case: if SQ =0, Square, R=1 inserts 0 0 0, (Thr can never be 0) and then, Thr allocated 4 bits 
% [0 ,sz1 . . . . 8 . . . .  . wlev . .  0 0 0 Thr. . 24] subsequentbits
% case: if SQ =1, Rectgl, R=1
% [SQ,sz1 . . . . 8 . . . . sz2  . 16 . .  . 20 . . . 24 . wlev. . 0   0  0  Thr . . 36]subsequentbits
% therefore 
% if SQ&R insert the Thr into the next byte, each byte assumed to accomodate 32 bits to avoid ambiguity of bitmapping.. 
j = 2; J = [1:32]+4+room; L = L + 1; j__ = 0; %room = 12-ifsq-R_;
if (SQ&R), Bitstobeencoded(J(1:R_)) = bitget(R, [1:R_]); end; % insert 4 bits of R to the next byte if rectangle (SQ=1). 
while(j<L),    
    if (any(Bitstobeencoded(J))),
       Enc_Sec(j) = sum(bitset(Enc_Sec(j), a1_32(1&Bitstobeencoded(J))));
       j__ = J(32);
    end;
    j = j + 1; J = J+32;
end; 

L_ = bitand(bL,31);


fid = fopen(fname,'wb');

if (L_ & any(a1_32(1&Bitstobeencoded(J(1:L_))))), 
    fwrite(fid, Enc_Sec,'uint32');
    ubitN = sprintf('ubit%d', L_); % remaning bits if not zero..
    fwrite(fid, sum( bitset(0, a1_32(1&Bitstobeencoded(J(1:L_))) ) ), ubitN);
    txt = sprintf('Binary encoded image file is %s, size %d bytes', ...
        fname, bitshift((j__+ L_ + 13), -3));
else
    fwrite(fid, Enc_Sec(1:j-1),'uint32');
    txt = sprintf('Binary encoded image file is %s, size %d bytes', ...
        fname, bitshift((j__ + 13), -3));
end
if (~j__)
    txt = 'CR rate chosen is too small for the size of image given!! Increase CR';
end
fclose(fid);
disp(txt); 
return

