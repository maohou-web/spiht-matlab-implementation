function y = DyadSymDecom_EvenX(x,qmf, mdqmf, p, n, e_, M, N)
% 1 level wavelet tranf of x with symmetric fir filters.. 
% this routine is called by FWT2_SBS_2d.m x is a 2d input.. 
% usage y = DyadSymDecom_EvenX(x,qmf,dqmf)
%  Inputs
%    x     2-d signal at fine scale
%    qmf   quadrature mirror filter
%    mdqmf  Mirror of dual quadrature mirror filter
%  Outputs
%    y : each half are low and high pass filtered signal, repectively

% 	p = length(qmf);
%   n = length(x); 
    Y = repmat(0, n);
	% symmetric extension of x
%     e_ = bitand(p, 1); % odd/even length ind is burried here.. 
    if p < n
        ph = bitshift(p+1, -1);
        ps = 1+e_;
        x = [x(ph:-1:ps, :); x; x(end-e_:-1:end-ph+1, :)]; 
    else 
        % NOT TESTED YET
        %if e_ 
        e = ~e_;
        for r=2:2:p, x=[x(r-e, :); x; x(n-e_, :)]; end
            %else
        %    for r=2:2:p, x=[x(:, r-1) x x(:, n)]'; end
        %end
    end

    
%     j = 1;
%     for r=1:2:n, y(j)=x(r:r+p-1)*qmf'; j=j+1; end
%     for r=2:2:n, y(j)=x(r:r+p-1)*mdqmf'; j=j+1; end
%%%%%%%%% My way of convolution polynomial mult..
% %      p_ = floor(p/2); pn = p+n;
% %      y_ = repmat(0, 1, pn-1);
% %      for r=1:p_, 
% %          x_ = x*qmf(r);
% %          y_(1:pn-r)=y_(1:pn-r)+x_(r:pn-1);
% %          y_(1:n+r-1) = y_(1:n-1+r)+x_(-r+p+1:pn-1); 
% %      end
% %      r=r+1;
% %      y_(1:pn-r)=y_(1:pn-r)+x(r:pn-1)*qmf(r);
% %      y(M) = y_(N-8);
% % 
% %      y_ = repmat(0, 1, pn-1);
% %      for r=2:p_, % high pass filter of daub(9,7), size 7 is one less than 9..
% %          x_ = x*mdqmf(r);
% %          y_(1:pn-r)=y_(1:pn-r)+x_(r:pn-1);
% %          y_(1:n+r-1) = y_(1:n-1+r)+x_(-r+p+1:pn-1); 
% %      end
% %      r=r+1;
% %      y_(1:pn-r)=y_(1:pn-r)+x(r:pn-1)*mdqmf(r);
% %      y(M+bitshift(n,-1)) = y_(N-7);

    Y = filter(qmf, 1, x); % LPF 
    y(M, :) = Y(N, :);  % p:2:n+p-1);  subsample even
    Y = filter(mdqmf, 1, x); 
    N = N+1; M = M+M(end);
    y(M, :) = Y(N, :); % (p+1:2:n+p)];  %HPF
%     Y = convn(x, [qmf; mdqmf]); subsample odd
%     y = [Y(1, p:2:n+p-1), Y(2, p+1:2:n+p)];
   
%   
% Part of Scalable Blockwise Spiht Version 01
% Written by M. Sakalli
% June, 2005
% This is Copyrighted Material
% Comments? e-mail msakalli@cipr.rpi.edu
    
