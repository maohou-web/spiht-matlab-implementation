function x = IWT2_SBS_(x, m, L, mrqmf, qmf)
% IWT2_SBS -- Inverse 2d Wavelet Transform
% Mustafa Sakalli, 2005, msakalli@CIPR.RPI.EDU
%            (symmetric extention, bi-orthogonal)
%  Usage
%    x = IWT2_SBS(wc,L,mrqmf,qmf)
%  Inputs
%      wc    2-d wavelet transform [n by n array, n arbitrary]
%      lev     coarse level
%      mrqmf   low-pass quadrature mirror filter
%      qmf  high-pas dual quadrature mirror filter
%  Outputs
%      x     2-d signal reconstructed from wc
%  Description
%      If wc is the result of a forward 2d wavelet transform, with
%           wc = FWT2_SBS(x,L,mrqmf,qmf)
%      then x = IWT2_SBS(wc,L,mrqmf,qmf) reconstructs x exactly if mrqmf is a nice
%      quadrature mirror filter..

    fl = length(mrqmf);
    e_ = bitand(fl, 1); 
	dpm = bitshift(m, -[L:-1:0]);

	for jscal=1:L,
	  bot = 1:dpm(jscal);
	  top = (dpm(jscal)+1):dpm(jscal+1); 
	  all = [bot top];
	  
	  
	  for iy=1:dpm(jscal+1),
	    x(all,iy) =  UpDyad_SBS_(x(bot,iy)', x(top,iy)', mrqmf, qmf, dpm(jscal+1), fl, e_)';
	  end
	  for ix=1:dpm(jscal+1),
	    x(ix,all) = UpDyad_SBS_(x(ix,bot), x(ix,top), mrqmf, qmf, dpm(jscal+1), fl, e_);
	  end
	end
    
% Modified by Mustafa Sakalli, 2005, msakalli@CIPR.RPI.EDU
% From Part of WaveLab Version 802
% Built Sunday, October 3, 1999 8:52:27 AM
% This is Copyrighted Material
% For Copying permissions see COPYING.m
% Comments? e-mail wavelab@stat.stanford.edu
