function x = UpDyad_SBS(a, b, mqmf, dqmf, n, p, e_)
% UpDyad_SBS -- Symmetric Upsampling operator
%  Usage
%    x = UpDyad_SBS(beta,alpha,qmf,dqmf)
%  Inputs
%    a  approx coefficients
%    d  detail coefficients
%    qmf   quadrature mirror filter
%    dqmf  dual quadrature mirror filter
%  Outputs
%    x     1-d signal at fine scale

x_ = repmat(0, n); 
x_(1:2:n, :)= a;
y_ = repmat(0, n);
y_(2:2:n, :)= b;

if p < n
    ph = bitshift(p+1, -1);
    ps = 1+e_;
    x_ = [x_(ph:-1:ps, :); x_; x_(end-e_:-1:end-ph+1, :)]; 
    y_ = [y_(ph:-1:ps, :); y_; y_(end-e_:-1:end-ph+1, :)]; 
else 
    % NOT TESTED YET
    %     if e_ 
    e = ~e_;
    for r=2:2:p, x_=[x_(r-e, :) x_ x_(n-e_, :)]; end
    for r=2:2:p, y_=[y_(r-e, :) y_ y_(n-e_, :)]; end
    %     else
    %         for r=2:2:p, x_=[x_(r-1) x_ x_(n)]; end
    %         for r=2:2:p, y_=[y_(r-1) y_ y_(n)]; end
    %     end
end

x_ = filter(dqmf,1,x_);

y_ = filter(mqmf,1,y_);
x =y_(p:p+n-1, :) + x_(p:p+n-1, :);


% 
% By 2005 M. Sakalli
% Part of SPIHT 

