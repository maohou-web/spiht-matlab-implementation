function wc = FWT2_SBS(x, m, lev, dqmf, mqmf)
% FWT2_SBS -- 2-dimensional wavelet transform
% Mustafa Sakalli, 2005, msakalli@CIPR.RPI.EDU
%              (symmetric extension, bi-orthogonal)
% Note: this routine assumes a line buffer.. x is in 1d array..  
% Usage
%    wc = FWT2_SBS_(x,m,lev,dqmf,qmf)
%  Inputs
%    x     2-d image (n by n array, n arbitrary)
%    lev     coarsest level
%    dqmf   low-pass quadrature mirror filter
%    qmf  high-pass dual quadrature mirror filter
%  Output
%    wc    2-d wavelet transform
%  Description
%    A two-dimensional Wavelet Transform is computed for the
%    matrix x. To reconstruct, use IWT2_SBS.

    fl = length(dqmf);
	wc = repmat(x, 1, 1); 
    dim = [m m]; dim = [dim; bitshift(dim, -1)]; 

    %mdqmf = MirrorSymmFilt(qmf);
    %reverse(MirrorSymmFilt(qmf));
    %dqmf = reverse(dqmf);
    e_ = bitand(fl, 1); 
    M__ = fl:2:dim(1,1)-1+fl; N__ = fl:2:dim(1,2)-1+fl;
    for jscal=1:lev,
        M = 1:dim(1, 1); M_ = 1:dim(2, 1); 
        N = 1:dim(1, 2); N_ = 1:dim(2, 2); 
        for i=M,
            wc(i, N) = DyadSymDecom_EvenX(wc(i, N), dqmf, mqmf, ...
                          fl, dim(1,1), e_, N_, N__(N_));
        end

        for i=N,
            wc(M, i) = DyadSymDecom_EvenX(wc(M, i)', dqmf, mqmf, ...
                          fl, dim(1, 2), e_, M_, M__(M_))';
        end
        dim = bitshift(dim, -1);
    end
    
    
% Modified by Mustafa Sakalli, 2005, msakalli@CIPR.RPI.EDU  
% Originally Part of WaveLab Version 802
% Built Sunday, October 3, 1999 8:52:27 AM
% This is Copyrighted Material
% For Copying permissions see COPYING.m
