function X = IWT_SBS_2d(X, dl, qmf, dqmf, Ln, flL, flH)
% IWT_SBS_2d -- Inverse 1d Wavelet Transform
%    (symmetric extention, bi-orthogonal, for images dimension > filter length)
%  Usage
%    X = IWT2_SBS(wc,dl,qmf,dqmf, Ln, flL, flH)
%  Inputs
%      X    2-d wavelet transform [n by n array, n arbitrary]
%      dl   WL Composition level
%      qmf   low-pass quadrature mirror filter
%      dqmf  high-pas dual quadrature mirror filter
%      Ln[row, column], flL, flH signal and filter lengths respctively. 
%      or Ln reresenting the length of the one dimensional signal 
%  Outputs
%      X  The signal reconstructed from X 
%  Description
%  If X is the result of a forward 2d wavelet transform, with
%      X = FWT2_SBS_2d(X,dl,qmf,dqmf, Ln, flL, flH) 
% signal can be 1 or 2 d and the length can be entered for one or two dimensional.. 


% Modified from the WaveLab Version 802 
%      by Mustafa Sakalli, 
%      CIPR, RPI, msakalli@cipr.rpi.edu

Lnc = Ln(1);
Lnr = 1; %1d
if numel(X)>Ln(1)
    if numel(Ln)>1,
        Lnr = Lnc; Lnc = Ln(2); 
    else
        Lnr = Lnc;
        Lnc = numel(X)/Lnr; 
    end
end

dd = max(bitget(Lnr-1, [1:32]).*[1:32]); %Dyadic Depth 
%	dpm = dyadpartition(Lnc);

flH_ = bitand(flH, 254); %if odd (flH-1)
flL_ = bitand(flL, 254); %if odd (flL-1)
hflH_ = bitshift(flH,-1); %half fl dl ((fl-1)/2)
hflL_ = bitshift(flL,-1); %half fl H ((fl-1)/2)

ex_H = bitshift(flH_-1, 1);
ex_L = bitshift(flL_-2, 1);

mqmf = ( (-1).^((-hflL_):hflL_) ).*qmf; 

if Lnr>1,
    dl_ = dl;
dpm(dd+1) = Lnr;	
for jscl=dd:-1:dl,
    dpm(jscl) = bitshift(dpm(jscl+1), -1)+bitget(dpm(jscl+1), 1);
    if (dpm(jscl+1)<flL-1), dl_ = jscl; break; end;
end

X = IWT_SBS_1d_block(X, mqmf, dqmf, dl_, dd, dpm, flL, flH, ...
    flL_, flH_, hflL_, hflH_, ex_H, ex_L, Lnc);
end
dpm(dd+1) = Lnc;	
for jscl=dd:-1:dl,
    dpm(jscl) = bitshift(dpm(jscl+1), -1)+bitget(dpm(jscl+1), 1);
    if (dpm(jscl+1)<flL-1), dl= jscl; break; end;
end

X = IWT_SBS_1d_block(X', mqmf, dqmf, dl, dd, dpm, flL, flH, ...
    flL_, flH_, hflL_, hflH_, ex_H, ex_L, Lnr)';
return


%This is like line buffer, the number of lines treated (in 1d) at once is Lnc..
function X = IWT_SBS_1d_block(X, mqmf, dqmf, dl, dd, dpm, flL, flH, ...
    flL_, flH_, hflL_, hflH_, ex_H, ex_L, Lnc)
% UpDyad_SBS -- Symmetric Upsampling and Filtering operator

for m=dl+1:dd, %Merging two bands
    La = dpm(m); 
    Ln = dpm(m+1);
    Lb = Ln-dpm(m);
    ALpHa = X(1:La, :);
    BeTa = X(La+1:Ln, :);
    odd_X = bitget(Ln, 1);
    bzeros = zeros(Ln+ex_L, Lnc); %Kept a little bit larger..

    %H side, extending, upsampling and filtering 
    UpsH = bzeros(1:ex_H+2*La, :);
    UpsH(1:2:ex_H+2*La, :) =[ALpHa(hflH_:-1:2, :); ALpHa; ALpHa(La-odd_X:-1:La-hflH_+~odd_X, :)];
    Coarse = filter(dqmf, 1, UpsH);%(La:-1:La-bitshift(flH,-1)+2)
    
    %dl side, extending, upsampling and filtering 
    UpsL = bzeros(1:ex_L+2*Lb, :);
    UpsL(1:2:ex_L+2*Lb, :) = [BeTa(hflL_-1:-1:1, :);... 
            BeTa; BeTa(Lb-~odd_X:-1:Lb-hflL_+1+odd_X, :)];
    Fine = filter(mqmf, 1, UpsL);
    
    %substituting.. 
    X(1:Ln, :) = Coarse(flH+[1:Ln], :) + Fine(flL+[1:Ln], :);
end
