function mSpiht_n(fname, sz, rate, fg)
%----------------------------------------------------------------------
% Set Partitioning in Hierarchal Trees (SPIHT) Algorithm 
%         in MATLAB Program Language
      
%     Non-recursive version 1.0    2/12/2008
 
% The authors of this MATLAB source code are Dr. Mustafa Sakalli (e-mail: msakalli@cipr.rpi.edu) and Dr. William A. Pearlman (e-mail: wpearlman@spiht.com). 

% Copyright 2008 by M. Sakalli and W. A. Pearlman
% The SPIHT algorithm contained herein is protected by patents.
% Plese read public license terms codified in mSpiht_README file.
% Detailed usage instructions are also contained in this file.
%-------------------------------------------------------------------------
% Arguments
% fname: enter the name of the raw image file as a string, ie 'lena'
%        and provide a file in the same directory with the suffix .raw,
%        e.g. lena.raw.
% sz: [row, col] if just one number is entered, the size assumed to be
% square.
% rate: bits per pel
% fg: configuring figure which is set to exact scale of image..  
%     enter 'n' for normal view, results visualized in ~square.. 
%     enter a number 1-5, for example, the default gray is 1, 
%     or enter the combination 'n3'.. 
%
%-------------------------------------------------------------

if nargin < 3 
    disp('Read "mSpiht_Readme" file for usage instructions and license information.');
    disp('Usage: Compress �image_name.raw� , r rows, c columns to CR bits/pel.');
    disp('> mSphit_n( ''image_name'',[r, c], CR <,''aspectratio-colormap''>)');
    disp('Example: Compress gray image ''goldy.raw'', dimensions 512x 720 (height x width)  to 0.50 bpp');
    disp('> mSpiht_n(''goldy'', [512,720],0.5)  %  normal view with gray colors');  
    disp('> mSpiht_n(''goldy'', [512,720],0.5, ''n5'')  %  stretched view with hot colors');  
    return
end

R = 1;
nsz = numel(sz);
if sz(nsz)<5, % This should be byte indicator (for hyperspectral images)
    R = sz(nsz); % assuming that image can be read inside.. 
    nsz = nsz-1;
end
switch nsz
    case 1, 
    r_im = sz;
    c_im = sz;
    case 2,
    r_im = sz(1);
    c_im = sz(2);
end

rtn = sprintf('\n'); 
if any(sz<17)
    disp([rtn 'Note: Note this program will not provide a good compression for the images']);
    disp('with the row or column numbers smaller than 17.');
    disp('Or the program might/will give an error and quit.');
end
% if (sel(1) == 'b') & ...
%         ((sum(bitget(r_im, 1:32))>1)|(sum(bitget(c_im, 1:32))>1)) 
%     disp([rtn 'Blockwise-version of spiht for image sizes not power of 2 hasn''t been implemented yet.']);
%     clear,
%     return;
% end

disp(sprintf('\nRaw Image %s.raw, size %d %d, to be n-compressed in %0.3f bpp rate\n', ...
      fname, r_im, c_im, rate));

% Load the raw file.
fid = fopen(sprintf('%s.raw', fname),'rb');
if (fid== -1) 
    txt = sprintf('\nCannot open image file %s.raw in the current directory.', fname); disp(txt); 
    disp('Usage: mSpiht(''fnameSq.raw'', [size], rate, options)');
    disp('Usage: mSpiht(''fnameRect.raw'', [row col], rate, options)');
    return
end
Imge = fread(fid, [c_im r_im], 'uchar')';
fclose(fid);
% End of the argument check process.
% ST: different level of decomposition in different directions 
% if ((sum(bitget(r_im, [1:11]))>1)|(sum(bitget(c_im, [1:11]))>1)) 
%     clear, disp('Image size is not fold of 2.');
%     return;
% end
% dyad_lev  = min([find(bitget(r_im, [1:11])) find(bitget(c_im, [1:11]))])-1;
% sz(2)=512;
% c_im = 512;
% Imge = Imge(r_im, c_im); 
Imsize = r_im * c_im; 
%Imge = Imge'; c_im_ = c_im; c_im = r_im; r_im = c_im_; 
if (Imsize ~= numel(Imge)) disp([rtn 'The Row and Column lengths should be entered wrong']);
    disp(sprintf('since the number of image elements (%d) is not equal to the declared size %d', numel(Imge), Imsize));
    clear, return; end;

bit_budget = floor(rate * Imsize);

% For the test.. Imge=floor(Imge*2/5);
% Step 1: W Transform image...  % biort 7,9..
% QMF filter coefficients of biort 7,9 [qmf, rqmf] = MakeBSFilter('CDF', [4 4]);
rqmf = [.026748757411 -.016864118443 -.078223266529 .266864118443 .602949018236 ...
        .266864118443 -.078223266529 -.016864118443 .026748757411] .*sqrt(2);
qmf = [-.045635881557 -.028771763114 .295635881557 .557543526229 ...
        .295635881557 -.028771763114 -.045635881557] .*sqrt(2);

dl =2; 
fl = [numel(rqmf), numel(qmf)];
hfl_ = bitshift(fl, -1);
fl_ = bitshift(hfl_, 1);

mqmf = ( (-1).^((-hfl_(2)):hfl_(2)) ).*qmf; 

dd = max(bitget(min(r_im, c_im)-1, [1:12]).*[1:12]); %Dyadic Depth 
dsb(dd+1, :) = [r_im, c_im]; %large_fl = fl_((fl_(1)<fl(2))+1);

for jscl=dd:-1:1,
    dsb(jscl, 1:2) = bitshift(dsb(jscl+1, 1:2), -1)+bitget(dsb(jscl+1, 1:2), 1);
    dsb(jscl, 3:4) = bitget(dsb(jscl+1, 1:2), 1);
    if any(dsb(jscl, 1:2) <(fl(1))), dl = jscl; break; end;
end
%Imge = Imge+2^13;
txt = sprintf('%sTransforming Image into %d sbs.', rtn, 3*(dd-dl+1)+1);
disp(txt); pause(.0001);

WTr_Im = FWT_SBS_2dbl(Imge, dd+1-dl, rqmf, mqmf, dsb(dl:dd+1, :), ([fl; hfl_])); 
for jscl=jscl:-1:1,
    dsb(jscl, 1:2) = bitshift(dsb(jscl+1, 1:2), -1)+bitget(dsb(jscl+1, 1:2), 1);
    dsb(jscl, 3:4) = bitget(dsb(jscl+1, 1:2), 1);
end

% dsb(jscl-2:jscl-1, 1) = bitshift(dsb(jscl, 1), -[2; 1])+bitget(dsb(jscl, 1), 1);
% dsb(jscl-2:jscl-1, 2) = bitshift(dsb(jscl, 2), -[2; 1])+bitget(dsb(jscl, 2), 1);
% dsb(jscl-2:jscl-1, 3:4) = bitget(dsb(jscl-1:jscl, 1:2), 1);

wdlev = dd-dl+1; % amir's case (the wavelet decomposition depth)

% % Step 2: SPIHT Encoding Stage
% L = dyad_lev; 
% wdlev = L-3; % amir's case (the wavelet decompostion depth)

% L_setpart determines the number of roots (trees) which is taken 3 for entire applications. 
% L_setpart = dyad_lev-1;
% L_setpart determines the number of roots (trees having the roots fr LLO) 
% which is taken 3 for entire applications of 512x512 image.
% which will differ in rect images.. = r_im*c_im/2^(dl-2) 
% L_setpart = dsb(dl,:)/4;
disp([rtn 'Compression with Spiht starts']); 
t0 = cputime;
EIm = mSpiht_E_nrec(WTr_Im, bit_budget, wdlev, dsb(dl-2:dd+1, :), R); %L_setpart, wdlev); 

if ~(EIm), clear, 
    disp([rtn,'%s-spiht stage could not be completed, clearing out.']); 
    return; 
end;

txt = sprintf('\nn-spiht stage is completed at %0.3f sec', cputime-t0); 
disp(txt); 

% Step 7: The compression rate is recalculated 
% since 'vf' will result different than the desired cr. 
rate = length(EIm)/numel(Imge);
CR = rate;
% % Step 3-4 part can be replaced with the other entropy encoders/decoders.. 
% Step 3: Binary Encoding. The name of encoded file is fname.sp 
disp([rtn,'Binary Encoding...']); 
% t0 = cputime; 
txt = sprintf('%s_%0.2f.sp', fname, rate);
BinEnc_(txt, EIm);
% 
% 
% Step 4: Binary decoding: Reading the same file and decompressing 
disp([rtn,'Binary Encoded file is reloaded, to generate the sequence for spiht decoder....']); 
EIm = BinDec_(txt);
% 
% Step 5: Spiht Decoding Stage
disp([rtn,'spiht-decompression starts....']); 
t0 = cputime; 
DIm = mSpiht_D_nrec(EIm);

if DIm<0, clear, return; end;
txt = sprintf('\nn-despiht stage is completed at %0.3f sec', cputime-t0); 
disp(txt); 

% Step 6: Reverse wavelet transform
txt = sprintf('%sReverse WT stage.', rtn);
disp(txt); 

mrqmf = ( (-1).^((-hfl_(1)):hfl_(1)) ) .* rqmf;
%RIm=iwt2_sbs(DIm, dyad_lev-wdlev, rqmf, qmf);
%RIm=iwt2_sbs(DIm, 3, rqmf, qmf);
%RIm=IWT2_SBS_(DIm, sz, wdlev, mrqmf, qmf);
if numel(DIm-1)
    RIm = IWT_SBS_2dbl(DIm, dd+1-dl, mrqmf, qmf, dsb(dl:dd+1, :), [fl; hfl_]);
else
    disp([rtn,'Something may be wrong with the decoded image seq. Quiting the prog.']);
    return;
end

% Imge = Imge(1:r_im, 1:c_im);
dif_ = RIm(:) - Imge(:);
mse = dif_'*dif_/Imsize;
psnr = 10*log10((bitshift(2^(8*R)-2, R*8) + 1)/mse);
%rmse = sqrt(dif_'*dif_)/sz;
%psnr = 20*log10((bitshift(1,R*8)-1)/rmse);


%%%%%%%%%************************
figcol = 'gray';
norm = 'equal tight';
if nargin>3,
    if (fg(1) == 'n')
        norm = 'normal'; 
        if (length(fg)-1), fg = fg(2);  
        end;
    end
    switch fg,  
    case '1', figcol = 'gray';
    case '2', figcol = 'bone';
    case '3', figcol = 'cool';
    case '4', figcol = 'hsv';
    case '5', figcol = 'hot'; end
end
figure('Name', 'mSPIHT-n CIPR-RPI-Prof Pearlman', 'NumberTitle', 'of');
colormap(figcol); 

splot(Imge, sprintf('Image %s with %d x %d.', fname, r_im, c_im), 1, norm, [1, c_im], [1, r_im], 10);
if (wdlev) 
    txt = sprintf('Log(Compressed wavelet coefficients of %d subbands)', 3*wdlev+1);
else
    txt = 'Log of Compressed image coefficients';
end
splot(log(abs(DIm)+.01), txt, 2, norm, dsb(dl:dd+1, 2), dsb(dl:dd+1, 1), 8);
splot(RIm, sprintf('Reconstructed Image: CR %0.3f bpp, PSNR %0.3f.', CR, psnr), 3, norm, [], [], 10);
splot(Imge-RIm, sprintf('(Original-RecImage) with mse %0.3f.', mse), 4, norm, [], [], 10);
%%%%%%%%%************************

txt = sprintf('\nCompressed at %0.3f bpp', CR); 
disp(txt); 
% Writing the reconstructed image (in raw format).
fid = fopen(sprintf('%s_Rec%0.2f_%dx%d.raw', fname, rate, r_im, c_im),'wb');
if (fid== -1) 
    txt = sprintf('\nCannot open file %s_Rec%0.2f_%dx%d.raw to write in the current directory.', fname, rate, r_im, c_im); 
    disp(txt); 
end
txt = sprintf('\nReconstructed image is %s_Rec%0.2f_%dx%d.raw (with PSNR=%0.3f) in the current directory.', ...
    fname, rate, r_im, c_im, psnr); 
disp(txt); 
fwrite(fid, RIm', 'uchar');
fclose(fid);
clear;
return

function splot(I, txt, n, norm, xnum, ynum, fnz)
subplot(sprintf('22%d', n)), show(I), 
set(gca, 'FontName','times',...
                    'FontAngle','italic',...
                    'FontSize', fnz, 'XTick', xnum, 'YTick', ynum);
%%title(txt);
title(regexprep(txt,'\', '\\\'));
eval(sprintf('axis %s',norm)),
return

% mlv = version; 
% if (sel == 'br' & (mlv(1) == '7')& (mlv(3)>0))
%     disp('At this moment blockwise recurive runs with matlab version below 7.1');
%     clear;
%     return;
% end;

% if any([r_im c_im]<[16 16]) 
%     disp('Image dimensions can not be smaller than 16');
%     clear;
%     return;
% end;
